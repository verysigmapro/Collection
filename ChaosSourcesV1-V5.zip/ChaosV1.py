import customtkinter
from pystyle import Colors, Colorate
import ctypes
import random
import json
import string
import pymem  # lua posted link what is this cap cap cap acp acp acp acp acp tf? cap not factual
import time
import re
import os
import psutil
from customtkinter import *
import requests


user32 = ctypes.windll.user32
def messageBox(title, text):
    return user32.MessageBoxW(0, text, title, 0x00001000)

p = psutil.Process(os.getpid())
p.nice(psutil.HIGH_PRIORITY_CLASS)

kernel32 = ctypes.WinDLL('kernel32')
ntdll = ctypes.WinDLL('ntdll')


def find_roblox_player_beta_folder():
    paths_to_check = [
        os.path.join(os.getenv("USERPROFILE"), "AppData", "Local", "Bloxstrap", "Versions"),
        os.path.join(os.getenv("USERPROFILE"), "AppData", "Local", "Roblox", "Versions"),
        os.path.join(os.getenv("PROGRAMFILES"), "Roblox"),
        os.path.join(os.getenv("PROGRAMFILES(X86)"), "Roblox")
    ]

    for path in paths_to_check:
        if os.path.exists(path):
            versions = os.listdir(path)
            for version in versions:
                player_beta_path = os.path.join(path, version, "RobloxPlayerBeta.exe")
                if os.path.exists(player_beta_path):
                    return os.path.join(path, version)

    return None


def find_roblox_uwp_folder():
    path_to_check = os.path.join(os.getenv("LOCALAPPDATA"), "Packages", "ROBLOXCorporation.ROBLOX_55nm5eh3cm0pr",
                                 "LocalState")

    if os.path.exists(path_to_check):
        return path_to_check

    return None


def create_client_settings_folder():
    roblox_player_beta_path = find_roblox_player_beta_folder()
    roblox_uwp_path = find_roblox_uwp_folder()

    if roblox_player_beta_path:
        client_settings_folder_path = os.path.join(os.path.dirname(roblox_player_beta_path), "ClientSettings")
        if not os.path.exists(client_settings_folder_path):
            os.makedirs(client_settings_folder_path)

        create_client_settings_file(client_settings_folder_path)
    elif roblox_uwp_path:
        client_settings_folder_path = os.path.join(roblox_uwp_path, "ClientSettings")
        if not os.path.exists(client_settings_folder_path):
            os.makedirs(client_settings_folder_path)

        create_client_settings_file(client_settings_folder_path)
    else:
        print("RobloxPlayerBeta.exe not found.")


def create_client_settings_file(folder_path):
    if folder_path:
        client_settings_folder = os.path.join(folder_path, "ClientSettings")
        if not os.path.exists(client_settings_folder):
            os.makedirs(client_settings_folder)

        file_path = os.path.join(client_settings_folder, "ClientAppSettings.json")
        if not os.path.exists(file_path):
            with open(file_path, "w") as file:
                json.dump({"DFIntTaskSchedulerTargetFps": 5588562}, file, indent=4)
        else:
            with open(file_path, "r+") as file:
                try:
                    content = json.load(file)
                except json.decoder.JSONDecodeError:
                    content = {}

                if content.get("DFIntTaskSchedulerTargetFps") != 5588562:
                    content["DFIntTaskSchedulerTargetFps"] = 5588562
                    file.seek(0)
                    json.dump(content, file, indent=4)
                    file.truncate()


def CloseRBLX():
    roblox_processes = ChaoSpolit.YieldForProgram("RobloxPlayerBeta.exe")
    if roblox_processes:
        os.system("taskkill /im RobloxPlayerBeta.exe")

    if not roblox_processes:
        print("/\RobloxPlayerBeta.exe was not found")
        exit()


os.system("cls" if os.name == "nt" else "clear")


def undetectname():
    letters = string.ascii_lowercase
    appname = ''.join(random.choice(letters) for _ in range(10))
    ctypes.windll.kernel32.SetConsoleTitleW(appname)


undetectname()

time.sleep(1)
print(Colorate.Horizontal(Colors.purple_to_red, "\nLoading...", 1))


class ChaoSpolit:
    def __init__(self, program_name):
        self.program_name = program_name

    def SimpleGetProcesses(self):
        return [proc.name() for proc in psutil.process_iter(["name"])]

    def SetParent(self, Instance, Parent, parentOffset):
        ChaoSpolit.Pymem.write_longlong(Instance + parentOffset, Parent)

    def __init__(self, ProgramName=None):
        self.ProgramName = ProgramName
        self.Pymem = pymem.Pymem()
        self.Addresses = {}
        self.Handle = None
        self.is64bit = True
        self.ProcessID = None
        self.PID = self.ProcessID
        if type(ProgramName) == str:
            self.Pymem = pymem.Pymem(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID
        elif type(ProgramName) == int:
            self.Pymem.open_process_from_id(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID

    def h2d(self, hz: str, bit: int = 16) -> int:
        if type(hz) == int:
            return hz
        return int(hz, bit)

    def d2h(self, dc: int, UseAuto=None) -> str:
        if type(dc) == str:
            return dc
        if UseAuto:
            if UseAuto == 32:
                dc = hex(dc & (2 ** 32 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2 ** 64 - 1)).replace("0x", "")
        else:
            if abs(dc) > 4294967295:
                dc = hex(dc & (2 ** 64 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2 ** 32 - 1)).replace("0x", "")
        if len(dc) > 8:
            while len(dc) < 16:
                dc = "0" + dc
        if len(dc) < 8:
            while len(dc) < 8:
                dc = "0" + dc
        return dc

    def PLAT(self, aob):
        if type(aob) == bytes:
            return aob
        trueB = bytearray(b'')
        aob = aob.replace(' ', '')
        PLATlist = []
        for i in range(0, len(aob), 2):
            PLATlist.append(aob[i:i + 2])
        for i in PLATlist:
            if "?" in i:
                trueB.extend(b'.')
            if "?" not in i:
                trueB.extend(re.escape(bytes.fromhex(i)))
        return bytes(trueB)

    # This constant is typically used to open a process with all possible access rights.

    def AOBSCANALL(self, AOB_HexArray, xreturn_multiple=False):
        """
        Searches for a given AOB (Address-Of-Buffer) pattern in the currently opened process.

        Parameters:
        AOB_HexArray (str): The AOB pattern to search for, represented as a hex string.
        xreturn_multiple (bool): Whether to return all matches or only the first match.

        Returns:
        A list of addresses where the AOB pattern was found, or None if the pattern was not found.
        """
        try:
            # Open the process with the appropriate access rights
            ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                0x1F0FFF,  # PROCESS_ALL_ACCESS
                False,  # False = do not inherit handles
                ChaoSpolit.Pymem.process_id,
            )

            # Define necessary ChaoSpolit functions
            PAGE_EXECUTE_READWRITE = 0x40
            ntdll = ctypes.windll.ntdll
            NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
            NtProtectVirtualMemory.restype = ctypes.c_long

            # Get the base address of the process
            base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

            # Remove read/write protection from the process memory
            old_protect = ctypes.c_ulong()
            size = ctypes.c_size_t(0x1000)
            NtProtectVirtualMemory(
                ChaoSpolit.Pymem.process_handle,
                ctypes.byref(ctypes.c_void_p(base_address)),
                ctypes.byref(size),
                PAGE_EXECUTE_READWRITE,
                ctypes.byref(old_protect),
            )

            # Get the base address of the process again (after removing read/write protection)
            base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

            # Re-enable read/write protection for the process memory
            NtProtectVirtualMemory(
                ChaoSpolit.Pymem.process_handle,
                ctypes.byref(ctypes.c_void_p(base_address)),
                ctypes.byref(size),
                old_protect,
                ctypes.byref(ctypes.c_ulong()),
            )

            # Now attempt the pattern scan
            return pymem.pattern.pattern_scan_all(
                self.Pymem.process_handle,
                self.PLAT(AOB_HexArray),
                return_multiple=xreturn_multiple,
            )
            # close the handle

        except Exception as e:
            print(f"WinAPI Error: {e}")
            # close handel before retrying
            ctypes.windll.kernel32.CloseHandle(ChaoSpolit.Pymem.process_handle)
            # Let's try bypassing read/write protection first.
            try:
                ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                    0x1F0FFF,  # PROCESS_ALL_ACCESS
                    False,  # False = do not inherit handles
                    ChaoSpolit.Pymem.process_id,
                )

                # Define necessary ChaoSpolit functions
                PAGE_EXECUTE_READWRITE = 0x40
                ntdll = ctypes.windll.ntdll
                NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
                NtProtectVirtualMemory.restype = ctypes.c_long

                # Get the base address of the process
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Remove read/write protection from the process memory
                old_protect = ctypes.c_ulong()
                size = ctypes.c_size_t(0x1000)
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    PAGE_EXECUTE_READWRITE,
                    ctypes.byref(old_protect),
                )

                # Get the base address of the process again (after removing read/write protection)
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Re-enable read/write protection for the process memory
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    old_protect,
                    ctypes.byref(ctypes.c_ulong()),
                )

                # Now attempt the pattern scan
                return pymem.pattern.pattern_scan_all(
                    self.Pymem.process_handle,
                    self.PLAT(AOB_HexArray),
                    return_multiple=xreturn_multiple,
                )
            except WindowsError as we:
                if we.winerror == 5:
                    ctypes.windll.kernel32.CloseHandle(ChaoSpolit.Pymem.process_handle)
                    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                        0x1F0FFF,  # PROCESS_ALL_ACCESS
                        False,  # False = do not inherit handles
                        ChaoSpolit.Pymem.process_id,
                    )

                # Define necessary ChaoSpolit functions
                PAGE_EXECUTE_READWRITE = 0x40
                ntdll = ctypes.windll.ntdll
                NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
                NtProtectVirtualMemory.restype = ctypes.c_long

                # Get the base address of the process
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Remove read/write protection from the process memory
                old_protect = ctypes.c_ulong()
                size = ctypes.c_size_t(0x1000)
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    PAGE_EXECUTE_READWRITE,
                    ctypes.byref(old_protect),
                )

                # Get the base address of the process again (after removing read/write protection)
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Re-enable read/write protection for the process memory
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    old_protect,
                    ctypes.byref(ctypes.c_ulong()),
                )

                # Now attempt the pattern scan
                return pymem.pattern.pattern_scan_all(
                    self.Pymem.process_handle,
                    self.PLAT(AOB_HexArray),
                    return_multiple=xreturn_multiple,
                )
            except Exception as e:
                print(f"Unknown error: ")

    def gethexc(self, hex: str):
        hex = hex.replace(" ", "")
        hxlist = []
        for i in range(0, len(hex), 2):
            hxlist.append(hex[i: i + 2])
        return len(hxlist)

    def hex2le(self, hex: str):
        lehex = hex.replace(" ", "")
        lelist = []
        if len(lehex) > 8:
            while len(lehex) < 16:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i: i + 2])
            lelist.reverse()
            return "".join(lelist)
        if len(lehex) < 9:
            while len(lehex) < 8:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i: i + 2])
            lelist.reverse()
            return "".join(lelist)

    def calcjmpop(self, des, cur):
        jmpopc = (self.h2d(des) - self.h2d(cur)) - 5
        jmpopc = hex(jmpopc & (2 ** 32 - 1)).replace("0x", "")
        if len(jmpopc) % 2 != 0:
            jmpopc = "0" + str(jmpopc)
        return jmpopc

    def isProgramGameActive(self):
        try:
            self.Pymem.read_char(self.Pymem.base_address)
            return True
        except:
            return False

    def DRP(self, Address: int, is64Bit: bool = None) -> int:
        Address = Address
        if type(Address) == str:
            Address = self.h2d(Address)
        if is64Bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        if self.is64bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        return int.from_bytes(self.Pymem.read_bytes(Address, 4), "little")

    def isValidPointer(self, Address: int, is64Bit: bool = None) -> bool:
        try:
            if type(Address) == str:
                Address = self.h2d(Address)
            self.Pymem.read_bytes(self.DRP(Address, is64Bit), 1)
            return True
        except:
            return False

    def GetModules(self) -> list:
        return list(self.Pymem.list_modules())

    def getAddressFromName(self, Address: str) -> int:
        if type(Address) == int:
            return Address
        AddressBase = 0
        AddressOffset = 0
        for i in self.GetModules():
            if i.name in Address:
                AddressBase = i.lpBaseOfDll
                AddressOffset = self.h2d(Address.replace(i.name + "+", ""))
                AddressNamed = AddressBase + AddressOffset
                return AddressNamed
            print("\033[91mAdress failed: \033[0m" + Address + " Line Rsp1")
            exit()

        return Address

    def getNameFromAddress(self, Address: int) -> str:
        memoryInfo = pymem.memory.virtual_query(self.Pymem.process_handle, Address)
        BaseAddress = memoryInfo.BaseAddress
        NameOfDLL = ""
        AddressOffset = 0
        for i in self.GetModules():
            if i.lpBaseOfDll == BaseAddress:
                NameOfDLL = i.name
                AddressOffset = Address - BaseAddress
                break
        if NameOfDLL == "":
            return Address
        NameOfAddress = NameOfDLL + "+" + self.d2h(AddressOffset)
        return NameOfAddress

    def getRawProcesses(self):
        toreturn = []
        for i in pymem.process.list_processes():
            toreturn.append(
                [
                    i.cntThreads,
                    i.cntUsage,
                    i.dwFlags,
                    i.dwSize,
                    i.pcPriClassBase,
                    i.szExeFile,
                    i.th32DefaultHeapID,
                    i.th32ModuleID,
                    i.th32ParentProcessID,
                    i.th32ProcessID,
                ]
            )
        return toreturn

    def SimpleGetProcesses(self):
        toreturn = []
        for i in self.getRawProcesses():
            toreturn.append({"Name": i[5].decode(), "Threads": i[0], "ProcessId": i[9]})
        return toreturn

    def YieldForProgram(self, programName, AutoOpen: bool = False, Limit=1):
        Count = 0
        while True:
            if Count >= Limit:
                return False
            ProcessesList = self.SimpleGetProcesses()
            for i in ProcessesList:
                if i["Name"] == programName:

                    if AutoOpen:
                        self.Pymem.open_process_from_id(i["ProcessId"])
                        self.ProgramName = programName
                        self.Handle = self.Pymem.process_handle
                        self.is64bit = pymem.process.is_64_bit(self.Handle)
                        self.ProcessID = self.Pymem.process_id
                        self.PID = self.ProcessID
                    return True
            time.sleep(1)
            Count += 1

    def ReadPointer(
            self, BaseAddress: int, Offsets_L2R: list, is64Bit: bool = None
    ) -> int:
        x = self.DRP(BaseAddress, is64Bit)
        y = Offsets_L2R
        z = x
        if y == None or len(y) == 0:
            return z
        count = 0
        for i in y:
            try:
                print(self.d2h(x + i))
                print(self.d2h(i))
                z = self.DRP(z + i, is64Bit)
                count += 1
                print(self.d2h(z))
            except:
                print("\033[91mNo index offset: \033[0m" + str(count) + " Rsp2")
                exit()

            return z
        return z

    def GetMemoryInfo(self, Address: int, Handle: int = None):
        if Handle:
            return pymem.memory.virtual_query(Handle, Address)
        else:
            return pymem.memory.virtual_query(self.Handle, Address)

    def MemoryInfoToDictionary(self, MemoryInfo):
        return {
            "BaseAddress": MemoryInfo.BaseAddress,
            "AllocationBase": MemoryInfo.AllocationBase,
            "AllocationProtect": MemoryInfo.AllocationProtect,
            "RegionSize": MemoryInfo.RegionSize,
            "State": MemoryInfo.State,
            "Protect": MemoryInfo.Protect,
            "Type": MemoryInfo.Type,
        }

    def SetProtection(
            self,
            Address: int,
            ProtectionType=0x40,
            Size: int = 4,
            OldProtect=ctypes.c_ulong(0),
    ):
        pymem.ressources.kernel32.VirtualProtectEx(
            self.Pymem.process_handle,
            Address,
            Size,
            ProtectionType,
            ctypes.byref(OldProtect),
        )
        return OldProtect

    def ChangeProtection(
            self,
            Address: int,
            ProtectionType=0x40,
            Size: int = 4,
            OldProtect=ctypes.c_ulong(0),
    ):
        return self.SetProtection(Address, ProtectionType, Size, OldProtect)

    def GetProtection(self, Address: int):
        return self.GetMemoryInfo(Address).Protect

    def KnowProtection(self, Protection):
        if Protection == 0x10:
            return "PAGE_EXECUTE"
        if Protection == 0x20:
            return "PAGE_EXECUTE_READ"
        if Protection == 0x40:
            return "PAGE_EXECUTE_READWRITE"
        if Protection == 0x80:
            return "PAGE_EXECUTE_WRITECOPY"
        if Protection == 0x01:
            return "PAGE_NOACCESS"
        if Protection == 0x02:
            return "PAGE_READONLY"
        if Protection == 0x04:
            return "PAGE_READWRITE"
        if Protection == 0x08:
            return "PAGE_WRITECOPY"
        if Protection == 0x100:
            return "PAGE_GUARD"
        if Protection == 0x200:
            return "PAGE_NOCACHE"
        if Protection == 0x400:
            return "PAGE_WRITECOMBINE"
        if Protection in ["PAGE_EXECUTE", "execute", "e"]:
            return 0x10
        if Protection in [
            "PAGE_EXECUTE_READ",
            "execute read",
            "read execute",
            "execute_read",
            "read_execute",
            "er",
            "re",
        ]:
            return 0x20
        if Protection in [
            "PAGE_EXECUTE_READWRITE",
            "execute read write",
            "execute write read",
            "write execute read",
            "write read execute",
            "read write execute",
            "read execute write",
            "erw",
            "ewr",
            "wre",
            "wer",
            "rew",
            "rwe",
        ]:
            return 0x40
        if Protection in [
            "PAGE_EXECUTE_WRITECOPY",
            "execute copy write",
            "execute write copy",
            "write execute copy",
            "write copy execute",
            "copy write execute",
            "copy execute write",
            "ecw",
            "ewc",
            "wce",
            "wec",
            "cew",
            "cwe",
        ]:
            return 0x80
        if Protection in ["PAGE_NOACCESS", "noaccess", "na", "n"]:
            return 0x01
        if Protection in ["PAGE_READONLY", "readonly", "ro", "r"]:
            return 0x02
        if Protection in ["PAGE_READWRITE", "read write", "write read", "wr", "rw"]:
            return 0x04
        if Protection in ["PAGE_WRITECOPY", "write copy", "copy write", "wc", "cw"]:
            return 0x08
        if Protection in ["PAGE_GUARD", "pg", "guard", "g"]:
            return 0x100
        if Protection in ["PAGE_NOCACHE", "nc", "nocache"]:
            return 0x200
        if Protection in ["PAGE_WRITECOMBINE", "write combine", "combine write"]:
            return 0x400
        return Protection

    def Suspend(self, pid: int = None):
        kernel32 = ctypes.WinDLL("kernel32.dll")
        if pid:
            kernel32.DebugActiveProcess(pid)
        if self.PID:
            kernel32.DebugActiveProcess(self.PID)

    def Resume(self, pid: int = None):
        kernel32 = ctypes.WinDLL("kernel32.dll")
        if pid:
            kernel32.DebugActiveProcessStop(pid)
        if self.PID:
            kernel32.DebugActiveProcessStop(self.PID)


ChaoSpolit = ChaoSpolit()

print(Colorate.Horizontal(Colors.purple_to_red, "Waiting for RobloxPlayerBeta.exe", 1))
while True:
    if ChaoSpolit.YieldForProgram("RobloxPlayerBeta.exe", True, 15):
        break
print(Colorate.Horizontal(Colors.purple_to_red, "Found Process", 1))


def ReadRobloxString(ExpectedAddress: int) -> str:
    try:
        StringCount = ChaoSpolit.Pymem.read_int(ExpectedAddress + 0x10)
        if StringCount > 15:
            return ChaoSpolit.Pymem.read_string(ChaoSpolit.DRP(ExpectedAddress), StringCount)
        return ChaoSpolit.Pymem.read_string(ExpectedAddress, StringCount)
    except TypeError as e:
        print(f"TypeError: {e} \n" + "Rsp3")
        exit()


def GetClassName(Instance: int) -> str:
    ExpectedAddress = ChaoSpolit.DRP(ChaoSpolit.DRP(Instance + 0x18) + 8)
    return ReadRobloxString(ExpectedAddress)


def setParent(Instance, Parent, parentOffset, childrenOffset):
    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
        0x1F0FFF,  # PROCESS_ALL_ACCESS
        False,  # False = do not inherit handles
        ChaoSpolit.Pymem.process_id,
    )

    # Define necessary ChaoSpolit functions
    PAGE_EXECUTE_READWRITE = 0x40
    ntdll = ctypes.windll.ntdll
    NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
    NtProtectVirtualMemory.restype = ctypes.c_long

    # Get the base address of the process
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Remove read/write protection from the process memory
    old_protect = ctypes.c_ulong()
    size = ctypes.c_size_t(0x1000)
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect),
    )

    # Get the base address of the process again (after removing read/write protection)
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Re-enable read/write protection for the process memory
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        old_protect,
        ctypes.byref(ctypes.c_ulong()),
    )

    ChaoSpolit.Pymem.write_longlong(Instance + parentOffset, Parent)
    newChildren = ChaoSpolit.Pymem.allocate(0x400)
    ChaoSpolit.Pymem.write_longlong(newChildren + 0, newChildren + 0x40)

    ptr = ChaoSpolit.Pymem.read_longlong(Parent + childrenOffset)
    childrenStart = ChaoSpolit.Pymem.read_longlong(ptr)
    childrenEnd = ChaoSpolit.Pymem.read_longlong(ptr + 8)

    if childrenStart == 0 or childrenEnd == 0 or childrenEnd <= childrenStart:
        print("\033[91mError: Invalid children range. Line: Rsp16\033[0m")
        exit()

    length = childrenEnd - childrenStart
    if length < 0:
        print("\033[91mError: Negative length for children array. Line: Rsp17\033[0m")
        exit()

    b = ChaoSpolit.Pymem.read_bytes(childrenStart, length)
    ChaoSpolit.Pymem.write_bytes(newChildren + 0x40, b, len(b))
    e = newChildren + 0x40 + length
    ChaoSpolit.Pymem.write_longlong(e, Instance)
    ChaoSpolit.Pymem.write_longlong(e + 8, ChaoSpolit.Pymem.read_longlong(Instance + 0x10))
    e = e + 0x10
    ChaoSpolit.Pymem.write_longlong(newChildren + 0x8, e)
    ChaoSpolit.Pymem.write_longlong(newChildren + 0x10, e)
    ctypes.windll.kernel32.CloseHandle(ChaoSpolit.Pymem.process_handle)


def inject():
    start = time.time()
    childrenOffset = 0
    players = 0
    nameOffset = int(requests.get("https://raw.githubusercontent.com/LLua-u/offsets/main/name").text)
    parentOffset = int(requests.get("https://raw.githubusercontent.com/LLua-u/offsets/main/parent").text)
    childrenOffset = int(requests.get("https://raw.githubusercontent.com/LLua-u/offsets/main/children").text)
    valid = False
    results = ChaoSpolit.AOBSCANALL(
        "506C6179657273??????????????????07000000000000000F", True
    )
    if not results:  # boblox issue not use \ok restatying boblox
        messageBox("Error: No results!", "Please restart the program and try again")
        exit()

    for rn in results:
        result = rn
        if not result:
            messageBox("Error: No results!", "Please restart the program and try again")
            exit()
        bres = ChaoSpolit.d2h(result)
        aobs = ""
        for i in range(1, 16 + 1):
            aobs = aobs + bres[i - 1: i]
        aobs = ChaoSpolit.hex2le(aobs)
        first = False
        res = ChaoSpolit.AOBSCANALL(aobs, True)
        if res:
            valid = False
            for i in res:
                try:
                    result = i
                    for j in range(1, 10 + 1):
                        address = result - (8 * j)
                        if not ChaoSpolit.isValidPointer(address):
                            continue
                        ptr = ChaoSpolit.Pymem.read_longlong(address)
                        if ChaoSpolit.isValidPointer(ptr):
                            address = ptr + 8
                            if not ChaoSpolit.isValidPointer(address):
                                continue
                            ptr = ChaoSpolit.Pymem.read_longlong(address)
                            if (
                                    ChaoSpolit.Pymem.read_string(ptr) == "Players"
                            ):
                                if not first:
                                    first = True
                                    players = (result - (8 * j)) - 0x18
                                    nameOffset = result - players
                                else:
                                    players = (result - (8 * j)) - 0x18
                                    nameOffset = result - players
                                    break
                    if valid:
                        break
                except:
                    pass
            if valid:
                break
        # dawg idk whats wrong lemme try on my pc
    if players == 0:
        messageBox("Error: Couldnt Get Datamodel", "Please restart the program and try again")
        while True:
            exit()
        return None
    dataModel = ChaoSpolit.Pymem.read_longlong(players + parentOffset)

    def GetNameAddress(Instance: int) -> int:
        try:

            ExpectedAddress = ChaoSpolit.DRP(Instance + nameOffset, True)

            return ExpectedAddress
        except TypeError as e:
            exit()

    def GetName(Instance: int) -> str:
        ExpectedAddress = GetNameAddress(Instance)
        return ReadRobloxString(ExpectedAddress)

    def GetChildren(Instance: int) -> str:
        ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
            0x1F0FFF,  # PROCESS_ALL_ACCESS
            False,  # False = do not inherit handles
            ChaoSpolit.Pymem.process_id,
        )

        # Define necessary ChaoSpolit functions
        PAGE_EXECUTE_READWRITE = 0x40
        ntdll = ctypes.windll.ntdll
        NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
        NtProtectVirtualMemory.restype = ctypes.c_long

        # Get the base address of the process
        base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

        # Remove read/write protection from the process memory
        old_protect = ctypes.c_ulong()
        size = ctypes.c_size_t(0x1000)
        NtProtectVirtualMemory(
            ChaoSpolit.Pymem.process_handle,
            ctypes.byref(ctypes.c_void_p(base_address)),
            ctypes.byref(size),
            PAGE_EXECUTE_READWRITE,
            ctypes.byref(old_protect),
        )

        # Get the base address of the process again (after removing read/write protection)
        base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

        # Re-enable read/write protection for the process memory
        NtProtectVirtualMemory(
            ChaoSpolit.Pymem.process_handle,
            ctypes.byref(ctypes.c_void_p(base_address)),
            ctypes.byref(size),
            old_protect,
            ctypes.byref(ctypes.c_ulong()),
        )
        ChildrenInstance = []
        InstanceAddress = Instance
        if not InstanceAddress:
            return False
        ChildrenStart = ChaoSpolit.DRP(InstanceAddress + childrenOffset, True)
        if ChildrenStart == 0:
            return []
        ChildrenEnd = ChaoSpolit.DRP(ChildrenStart + 8, True)
        OffsetAddressPerChild = 0x10
        CurrentChildAddress = ChaoSpolit.DRP(ChildrenStart, True)
        for i in range(0, 9000):
            if i == 8999:
                messageBox("Error: Invalid Children", "You are not the father jk restart the program")
                exit()

            if CurrentChildAddress == ChildrenEnd:
                break
            ChildrenInstance.append(ChaoSpolit.Pymem.read_longlong(CurrentChildAddress))
            CurrentChildAddress += OffsetAddressPerChild

        return ChildrenInstance

    def GetParent(Instance: int) -> int:
        return ChaoSpolit.DRP(Instance + parentOffset, True)

    def FindFirstChild(Instance: int, ChildName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetName(i) == ChildName:
                return i

    def FindFirstChildOfClass(Instance: int, ClassName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetClassName(i) == ClassName:
                return i

    def GetDescendants(Instance: int) -> list:

        descendants = []

        def _get_descendants_recursive(current_instance: int):
            children = GetChildren(current_instance)
            descendants.extend(children)  # Add direct children

            # Recurse into each child
            for child in children:
                _get_descendants_recursive(child)

        _get_descendants_recursive(Instance)
        return descendants

    class toInstance:
        def __init__(self, address: int = 0):
            self.Address = address
            self.Self = address
            self.Name = GetName(address)
            self.ClassName = GetClassName(address)
            self.Parent = GetParent(address)

        def getChildren(self):
            return GetChildren(self.Address)

        def findFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def findFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def setParent(self, Parent):
            setParent(self.Address, Parent)

        def GetChildren(self):
            return GetChildren(self.Address)

        def GetDescendants(self):
            return GetDescendants(self.Address)

        def FindFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def FindFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def SetParent(self, Parent):
            setParent(self.Address, Parent, parentOffset, childrenOffset)

    players = toInstance(players)
    game = toInstance(dataModel)
    localPlayer = toInstance(players.GetChildren()[0])
    print(localPlayer.Name)
    animateScript = None
    workspace = toInstance(game.getChildren()[0])
    character_found = False
    character = None

    for obj in workspace.GetDescendants():
        obj_name = GetName(obj)
        if obj_name == localPlayer.Name:
            character = toInstance(obj)
            character_found = True
            messageBox("Found Character", "Successfully found Character")
            break

    if not character_found:
        messageBox("Error: No Character", "Please check you are in a supported game.")
        exit()

    animateScript = character.findFirstClass("LocalScript")
    if animateScript is None:
        messageBox("Error: No Script", "No localscript to inject too")
        exit()
    print(Colorate.Horizontal(Colors.purple_to_red, "Attaching to process...", 1))
    targetScript = toInstance(animateScript)
    injectScript = None
    results = ChaoSpolit.AOBSCANALL("496E6A656374????????????????????06", True)
    if results == []:
        messageBox("Error: Your teleport place is bad", "use the official one for full support.")
        exit()
    for rn in results:
        result = rn
        bres = ChaoSpolit.d2h(result)
        aobs = ""
        for i in range(1, 16 + 1):
            aobs = aobs + bres[i - 1: i]
        aobs = ChaoSpolit.hex2le(aobs)
        first = False
        res = ChaoSpolit.AOBSCANALL(aobs, True)
        if res:
            valid = False
            for i in res:
                result = i
                if (
                        ChaoSpolit.Pymem.read_longlong(result - nameOffset + 8) == result - nameOffset
                ):
                    injectScript = result - nameOffset
                    valid = True
                    break
        if valid:
            break
    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
        0x1F0FFF,  # PROCESS_ALL_ACCESS
        False,  # False = do not inherit handles
        ChaoSpolit.Pymem.process_id,
    )

    # Define necessary ChaoSpolit functions
    PAGE_EXECUTE_READWRITE = 0x40
    ntdll = ctypes.windll.ntdll
    NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
    NtProtectVirtualMemory.restype = ctypes.c_long

    # Get the base address of the process
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Remove read/write protection from the process memory
    old_protect = ctypes.c_ulong()
    size = ctypes.c_size_t(0x1000)
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect),
    )

    # Get the base address of the process again (after removing read/write protection)
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Re-enable read/write protection for the process memory
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        old_protect,
        ctypes.byref(ctypes.c_ulong()),
    )
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        old_protect,
        ctypes.byref(ctypes.c_ulong()),
    )
    injectScript = toInstance(injectScript)
    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(0x1F0FFF, False, ChaoSpolit.Pymem.process_id)
    # Define necessary ChaoSpolit

    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
        0x1F0FFF,  # PROCESS_ALL_ACCESS
        False,  # False = do not inherit handles
        ChaoSpolit.Pymem.process_id,
    )

    # Define necessary ChaoSpolit functions
    PAGE_EXECUTE_READWRITE = 0x40
    ntdll = ctypes.windll.ntdll
    NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
    NtProtectVirtualMemory.restype = ctypes.c_long

    # Get the base address of the process
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Remove read/write protection from the process memory
    old_protect = ctypes.c_ulong()
    size = ctypes.c_size_t(0x1000)
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect),
    )

    # Get the base address of the process again (after removing read/write protection)
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

    # Re-enable read/write protection for the process memory

    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        old_protect,
        ctypes.byref(ctypes.c_ulong()),
    )

    # Get process base address
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)
    # Remove read/write protection
    ctypes.windll.kernel32.VirtualProtectEx(
        ChaoSpolit.Pymem.process_handle,
        base_address,
        ctypes.c_size_t(0x1000),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(ctypes.c_ulong())
    )
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        old_protect,
        ctypes.byref(ctypes.c_ulong()),
    )
    b = ChaoSpolit.Pymem.read_bytes(injectScript.Self + 0x100, 0x150)
    ChaoSpolit.Pymem.write_bytes(targetScript.Self + 0x100, b, len(b))
    coreGui = toInstance(game.GetChildren()[31])
    targetScript.SetParent(coreGui.Self)

    return True


customtkinter.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"

# Themes: "blue" (standard), "green", "dark-blue"


class App(customtkinter.CTk):
    def lmao(self):
        if inject():
            Roblox = ChaoSpolit.YieldForProgram("RobloxPlayerBeta.exe")
            messageBox("Success: Injected Correctly", "Please respawn to load the ui")
            exit()
        else:
            ctypes.windll.kernel32.CloseHandle(ChaoSpolit.Pymem.process_handle)
            Roblox = ChaoSpolit.YieldForProgram("RobloxPlayerBeta.exe")
            messageBox("Error: Failed to inject","Reason for error: Tried to read not open page, Please Restart your device and try again")
            inject()

    def __init__(self):
        super().__init__()

        self.title("Chaos Injector")
        self.geometry(f"{300}x{200}")
        self.resizable(False, False)
        # configure grid layout (4x4)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure((2, 3), weight=0)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # create sidebar frame with widgets
        self.main_button_1 = customtkinter.CTkButton(master=self, text="Inject", border_width=2,
                                                     text_color=("gray10", "#DCE4EE"), command=self.lmao)
        self.main_button_1.grid(row=3, column=1, padx=(10, 10), pady=(10, 10), sticky="nsew")

        # create textbox
        # update log
        self.textbox = customtkinter.CTkTextbox(self, width=250)
        self.textbox.grid(row=0, column=1, padx=(10, 0), pady=(10, 0), sticky="nsew")
        self.textbox.insert("end", """[Click Inject once you teleport to a game]

Changelogs:""")
        self.textbox.configure(state="disabled")

    def change_appearance_mode_event(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)

    def sidebar_button_event(self):
        print("sidebar_button click")

    def changeval(self):
        if inject():
            self.main_button_1.configure(text="Injected")


if __name__ == "__main__":
    uwp = find_roblox_uwp_folder()
    path = find_roblox_player_beta_folder()
    create_client_settings_folder()
    create_client_settings_file(uwp)
    create_client_settings_file(path)
    app = App()
    app.mainloop()