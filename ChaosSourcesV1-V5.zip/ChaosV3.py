from pystyle import Colors, Colorate
import ctypes
import random
import string
import pymem
import time
import re
import os
import psutil
import subprocess
import threading
import requests
import hashlib
import urllib
import glob
import json
import requests
import ssl
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.poolmanager import PoolManager
import tempfile

cert = """
-----BEGIN CERTIFICATE-----
MIIE4TCCA8mgAwIBAgISAwmt592pmLYBVax/P+51AGDNMA0GCSqGSIb3DQEBCwUA
MDIxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1MZXQncyBFbmNyeXB0MQswCQYDVQQD
EwJSMzAeFw0yNDA0MDIxNTQ5MzVaFw0yNDA3MDExNTQ5MzRaMBUxEzARBgNVBAMT
CmJ5ZnJvbi5sb2wwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCoVVy/
Lh8usb0nwz6resMIuAbO/0qjRjyeZU8WWc2ofzEejiLtH2fGxKaqVe0M5Ca50Ztk
MQSgdK8D2OzKTRW3jRoAVocWCAB5NHVuesHn4PHnSL5mVd6nEkUHjvqdNJDEI6pe
GEfcOBvyxA+aafYJWL+nKXvCEBOWh349XkzAxB4reiTNqBowumk00hwIseMYmTY+
FSdepDNzHo1XGJmNNba+m58MaqYUzSK+qqzHpBe1uwixjp1PCuaJTVMz0ycrn/Tb
7TQgks23hJvQoJiMdATq/tua35DjkfVCFRGmafaZQYsWT0mO+HgYoffibaHUEbPu
4vpF6wACzhgHJigRAgMBAAGjggIMMIICCDAOBgNVHQ8BAf8EBAMCBaAwHQYDVR0l
BBYwFAYIKwYBBQUHAwEGCCsGAQUFBwMCMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYE
FKAXfi5DYq+IvhG+puMA/5aWCHWPMB8GA1UdIwQYMBaAFBQusxe3WFbLrlAJQOYf
r52LFMLGMFUGCCsGAQUFBwEBBEkwRzAhBggrBgEFBQcwAYYVaHR0cDovL3IzLm8u
bGVuY3Iub3JnMCIGCCsGAQUFBzAChhZodHRwOi8vcjMuaS5sZW5jci5vcmcvMBUG
A1UdEQQOMAyCCmJ5ZnJvbi5sb2wwEwYDVR0gBAwwCjAIBgZngQwBAgEwggEEBgor
BgEEAdZ5AgQCBIH1BIHyAPAAdgDf4VbrqgWvtZwPhnGNqMAyTq5W2W6n9aVqAdHB
O75SXAAAAY6ft1MRAAAEAwBHMEUCIAfFaEx0FFSyHKpihRtfL2p2Uzj80nSSZ9MQ
Qh241GIVAiEAu/zFbuobWRAKQHhQvq2XupDu12SnOXdscD2qF/iz1c4AdgBIsONr
2qZHNA/lagL6nTDrHFIBy1bdLIHZu7+rOdiEcwAAAY6ft1P+AAAEAwBHMEUCICod
L89ZnhQPFAAqsurfYcWo2jp5v7mQNFb0Ozde8ILbAiEAxeciEYDhSdWp09L9epli
sR86PigGnSU6UllYjrnb8jQwDQYJKoZIhvcNAQELBQADggEBALFUVi1ij6xOEzXn
RqOxKJ5d8yNfYNYQJD1tFgQwtSUAhV/KhkCdxw/7AF4QsFcvifMAifTQH7DjxUII
a0WfwsbpEmdvJ1rEVpNJY2FrDK54JgsAQqvDvHPpN9f6U3ruF3vq9TkVjlBFmhns
Vsg2+APwtpzHTkqI6ln5QI5Ag0OLAzUXseIyhTZlgOkW7Hj4LcgWXp4Yp3dRQ8p3
SW85IA4lM5Xa7jz29ApejyxvSGfCgO1GNlAwULfqEqHcVT3nixdgJWE1bvEltzc7
ODVbXn7HXJnAMAEytELRhrWnO+cR1HdIJkXsnaWR9e6m5TC2fXpGmK4C/bogAx2u
mD9vASc=
-----END CERTIFICATE-----
"""

class SSLAdapter(HTTPAdapter):
    def __init__(self, cert_content):
        self.cert_file = tempfile.NamedTemporaryFile(delete=True)
        self.cert_file.write(cert_content.encode())
        self.cert_file.flush()
        super().__init__()

    def init_poolmanager(self, connections, maxsize, block=False):
        self.poolmanager = PoolManager(num_pools=connections,
                                       maxsize=maxsize,
                                       block=block,
                                       ssl_version=ssl.PROTOCOL_TLSv1_2,
                                       cert_reqs='CERT_REQUIRED',
                                       ca_certs=self.cert_file.name)  # Use the certificate file

p = psutil.Process(os.getpid())
p.nice(psutil.HIGH_PRIORITY_CLASS)
global selector
thisver = "beta_0438"
def tamperdetected():
    return None # disable the tamper func ~ @dexftl
    webhook = "https://discord.com/api/webhooks/1225098688154832987/GkYCaZCmLGYFosGq0rxWUxKkyuwj-ld2o_vaRby8UgLNgkdXNGagzUhFNkn99HzJz22s"
    hw = subprocess.check_output('wmic csproduct get uuid').decode().split('\n')[1].strip()
    embed = {
        "title": "Tamper Detected",
        "description": f"***IP:***``` Getting Ip is disabled```\n**HWID:***```{hw}```",
        "color": 16711680  # Red color
    }
    requests.post(webhook, json={"embeds": [embed]})
    print(f"\nYou have won free Chaos beta, DM byfronlol on Discord with your unique ID: ", ran)
    # destroy the file
    cwd = os.getcwd()   
    py_files = glob.glob(os.path.join(cwd, '*.py'))
    for file in py_files:
        os.remove(file)
    exit()        

def checkleak():
    version = requests.get("https://byfron.lol/api/version?version="+thisver).json()

    if version.get('message') == '404 | Leaker found':
        tamperdetected()
def randomstrings():
    return ''.join(random.choice(string.ascii_lowercase) for i in range(10))
ran = randomstrings()

def checkproxy():
    while True:
        if urllib.request.getproxies() == {}:
            return False
        else:
            tamperdetected()
            return True
        
   
    


import time

def check_processes(process_names):
    while True:
        for process in psutil.process_iter(['name']):
            #get every process
            for name in process_names:
                #for every blacklisted name
                if name in process.info['name'].lower():
                    #if name is in the process info
                    # print("tamper found!!!") # debug
                    #then flag
                    tamperdetected()
                
        time.sleep(1)  # pause for 1 second

processes_to_check = ["gdb", "debug", "dbg", "proxy", "ida", "fiddle", "dnspy", "socks", "vpn", "psiphon", "ultrasurf", "ghidra", "compile", "spoof", "woof"]
t = threading.Thread(target=check_processes, args=(processes_to_check,))
t.start()

os.system("cls")
banner = """

░█████╗░██╗░░██╗░█████╗░░█████╗░░██████╗██████╗░░█████╗░██╗░░░░░██╗████████╗             [Version]: Beta V3
██╔══██╗██║░░██║██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██║░░░░░██║╚══██╔══╝             [Deafult]: [RobloxPlayerBeta.exe]
██║░░╚═╝███████║███████║██║░░██║╚█████╗░██████╔╝██║░░██║██║░░░░░██║░░░██║░░░             [1] WEB
██║░░██╗██╔══██║██╔══██║██║░░██║░╚═══██╗██╔═══╝░██║░░██║██║░░░░░██║░░░██║░░░             [2] UWP
╚█████╔╝██║░░██║██║░░██║╚█████╔╝██████╔╝██║░░░░░╚█████╔╝███████╗██║░░░██║░░░            
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░╚════╝░╚═════╝░╚═╝░░░░░░╚════╝░╚══════╝╚═╝░░░╚═╝░░░          """
print(Colorate.Horizontal(Colors.purple_to_blue, banner, 1))


def colorprint(text):
    print(Colorate.Horizontal(Colors.cyan_to_blue, text))

def checkkey(): # cracked....
    #url = "https://byfron.lol/api/keyids"
    key = input(Colorate.DiagonalBackwards(Colors.cyan_to_blue, "Enter your key: ", 1))
    if key:
        return True
    
    #hw = subprocess.check_output('wmic csproduct get uuid').decode().split('\n')[1].strip()
    #session = requests.Session()
    #session.mount(url, SSLAdapter(cert))
    #r = session.get(url=url + "?keyid=" + key +f"&hwid={hw}")
    #response_data = json.loads(r.text)

    #if response_data.get('status') == 'error' and response_data.get('message') == '403 | Blocked - HWID does not match':
    #    print("Your HWID doesn't match the key HWID")
    #    return False
    #elif response_data.get('status') == 'error' and response_data.get('message') == '404 | Key ID not found':
    #    print("Key expired or not found in the database")
    #    return False
    #elif response_data.get('status') == 'success' and 'Key ID is valid' in response_data.get('message'):
    #    return True
    #else:
    #    print(response_data)
        
if checkkey():
    
    pass
else:
    os.system("cls")
    print(Colorate.Horizontal(Colors.purple_to_blue, banner, 1))
    print("Invalid Key Get It From: https://byfron.lol/")
    exit()
    
os.system("cls")
print(Colorate.Horizontal(Colors.purple_to_blue, banner, 1))   
print(Colorate.Horizontal(Colors.cyan_to_blue, "Valide Key",1))
selectorsec = input(Colorate.Horizontal(Colors.cyan_to_blue, "\nSelect the Roblox version you want to use: ", 1))
if selectorsec == "2":
    selector = "Windows10Universal.exe"
else:
    selector = "RobloxPlayerBeta.exe"
def CloseRBLX():
    roblox_processes = ChaoSpolit.YieldForProgram(f"{selector}")
    if roblox_processes:
        os.system(f"taskkill /im {selector}")

    if not roblox_processes:
        print("/\{selector} was not found")
        exit()

os.system("cls" if os.name == "nt" else "clear")

# This is a flag that the thread will check to see if it should stop
stop_thread = False

def undetectname():# silly bypass
    global stop_thread
    while not stop_thread:
        letters = string.ascii_lowercase
        appname = ''.join(random.choice(letters) for _ in range(40))
        ctypes.windll.kernel32.SetConsoleTitleW(appname)
        


def init():
    """# docs by tabnine
    This function is used to check for updates and display them to the user.
    """
    url = "https://capi-3ns5.onrender.com/latestversion"# i am dumb
    req = requests.get(url=url)
    #convert the output : [1] into only the number in it
    res = req.text[1:-1]
    # print(res)# debug [purposes]
    print(Colorate.Horizontal(Colors.cyan_to_blue, f"Latest Version : {res}..."))
    print(Colorate.Horizontal(Colors.cyan_to_blue, "Discord: https://discord.gg/chaosploit...", 1))
    pass
    #else:
    #    print(Colorate.Horizontal(Colors.cyan_to_blue, "Update Soon Please Join: https://discord.gg/chaosploit...", 1))
    #    exit()
        

init()

class ChaoSpolit:
    def __init__(self, program_name):
        self.program_name = program_name

    def SimpleGetProcesses(self):
        return [proc.name() for proc in psutil.process_iter(["name"])]
    
    def SetParent(self, Instance, Parent, parentOffset):
        ChaoSpolit.Pymem.write_longlong(Instance + parentOffset, Parent)

    def __init__(self, ProgramName=None):# init
        self.ProgramName = ProgramName
        self.Pymem = pymem.Pymem()
        self.Addresses = {}
        self.Handle = None
        self.is64bit = True
        self.ProcessID = None
        self.PID = self.ProcessID
        if type(ProgramName) == str:
            self.Pymem = pymem.Pymem(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID
        elif type(ProgramName) == int:
            self.Pymem.open_process_from_id(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID

    def h2d(self, hz: str, bit: int = 16) -> int:
        if type(hz) == int:
            return hz
        return int(hz, bit)

    def d2h(self, dc: int, UseAuto=None) -> str:
        if type(dc) == str:
            return dc
        if UseAuto:
            if UseAuto == 32:
                dc = hex(dc & (2**32 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2**64 - 1)).replace("0x", "")
        else:
            if abs(dc) > 4294967295:
                dc = hex(dc & (2**64 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2**32 - 1)).replace("0x", "")
        if len(dc) > 8:
            while len(dc) < 16:
                dc = "0" + dc
        if len(dc) < 8:
            while len(dc) < 8:
                dc = "0" + dc
        return dc

    def PLAT(self, aob: str):
        if type(aob) == bytes:
            return aob
        trueB = bytearray(b"")
        aob = aob.replace(" ", "")
        PLATlist = []
        for i in range(0, len(aob), 2):
            PLATlist.append(aob[i : i + 2])
        for i in PLATlist:
            if "?" in i:
                trueB.extend(b".")
            if "?" not in i:
                trueB.extend(re.escape(bytes.fromhex(i)))
        return bytes(trueB)

    def AOBSCANALL(self, AOB_HexArray, xreturn_multiple=False):
        """
        Searches for a given AOB (Address-Of-Buffer) pattern in the currently opened process.

        Parameters:
        AOB_HexArray (str): The AOB pattern to search for, represented as a hex string.
        xreturn_multiple (bool): Whether to return all matches or only the first match.

        Returns:
        A list of addresses where the AOB pattern was found, or None if the pattern was not found.
        """
        try:
            # Open the process with the appropriate access rights
            ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                0x1F0FFF,  # PROCESS_ALL_ACCESS
                False,  # False = do not inherit handles
                ChaoSpolit.Pymem.process_id,
            )

            # Define necessary ChaoSpolit functions
            PAGE_EXECUTE_READWRITE = 0x40
            ntdll = ctypes.windll.ntdll
            NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
            NtProtectVirtualMemory.restype = ctypes.c_long

            # Get the base address of the process
            base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

            # Remove read/write protection from the process memory
            old_protect = ctypes.c_ulong()
            size = ctypes.c_size_t(0x1000)
            NtProtectVirtualMemory(
                ChaoSpolit.Pymem.process_handle,
                ctypes.byref(ctypes.c_void_p(base_address)),
                ctypes.byref(size),
                PAGE_EXECUTE_READWRITE,
                ctypes.byref(old_protect),
            )

            # Get the base address of the process again (after removing read/write protection)
            base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

            # Re-enable read/write protection for the process memory
            NtProtectVirtualMemory(
                ChaoSpolit.Pymem.process_handle,
                ctypes.byref(ctypes.c_void_p(base_address)),
                ctypes.byref(size),
                old_protect,
                ctypes.byref(ctypes.c_ulong()),
            )

            # Now attempt the pattern scan
            return pymem.pattern.pattern_scan_all(
                self.Pymem.process_handle,
                self.PLAT(AOB_HexArray),
                return_multiple=xreturn_multiple,
            )
        except Exception as e:
            print(f"WinAPI Error: {e}")
            # Let's try bypassing read/write protection first.
            try:
                ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                    0x1F0FFF,  # PROCESS_ALL_ACCESS
                    False,  # False = do not inherit handles
                    ChaoSpolit.Pymem.process_id,
                )

                # Define necessary ChaoSpolit functions
                PAGE_EXECUTE_READWRITE = 0x40
                ntdll = ctypes.windll.ntdll
                NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
                NtProtectVirtualMemory.restype = ctypes.c_long

                # Get the base address of the process
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Remove read/write protection from the process memory
                old_protect = ctypes.c_ulong()
                size = ctypes.c_size_t(0x1000)
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    PAGE_EXECUTE_READWRITE,
                    ctypes.byref(old_protect),
                )

                # Get the base address of the process again (after removing read/write protection)
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Re-enable read/write protection for the process memory
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    old_protect,
                    ctypes.byref(ctypes.c_ulong()),
                )

                # Now attempt the pattern scan
                return pymem.pattern.pattern_scan_all(
                    self.Pymem.process_handle,
                    self.PLAT(AOB_HexArray),
                    return_multiple=xreturn_multiple,
                )
            except WindowsError as we:
                if we.winerror == 5:
                    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                        0x1F0FFF,  # PROCESS_ALL_ACCESS
                        False,  # False = do not inherit handles
                        ChaoSpolit.Pymem.process_id,
                    )

                # Define necessary ChaoSpolit functions
                PAGE_EXECUTE_READWRITE = 0x40
                ntdll = ctypes.windll.ntdll
                NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
                NtProtectVirtualMemory.restype = ctypes.c_long

                # Get the base address of the process
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Remove read/write protection from the process memory
                old_protect = ctypes.c_ulong()
                size = ctypes.c_size_t(0x1000)
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    PAGE_EXECUTE_READWRITE,
                    ctypes.byref(old_protect),
                )

                # Get the base address of the process again (after removing read/write protection)
                base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Re-enable read/write protection for the process memory
                NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    old_protect,
                    ctypes.byref(ctypes.c_ulong()),
                )

                # Now attempt the pattern scan
                return pymem.pattern.pattern_scan_all(
                    self.Pymem.process_handle,
                    self.PLAT(AOB_HexArray),
                    return_multiple=xreturn_multiple,
                )
            except Exception as e:
                print(f"Unknown error: ")


    def hex2le(self, hex: str):
        lehex = hex.replace(" ", "")
        lelist = []
        if len(lehex) > 8:
            while len(lehex) < 16:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i : i + 2])
            lelist.reverse()
            return "".join(lelist)
        if len(lehex) < 9:
            while len(lehex) < 8:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i : i + 2])
            lelist.reverse()
            return "".join(lelist)


    def isProgramGameActive(self):
        try:
            self.Pymem.read_char(self.Pymem.base_address)
            return True
        except:
            return False

    def DRP(self, Address: int, is64Bit: bool = None) -> int:
        Address = Address
        if type(Address) == str:
            Address = self.h2d(Address)
        if is64Bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        if self.is64bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        return int.from_bytes(self.Pymem.read_bytes(Address, 4), "little")


    def getRawProcesses(self):
        toreturn = []
        for i in pymem.process.list_processes():
            toreturn.append(
                [
                    i.cntThreads,
                    i.cntUsage,
                    i.dwFlags,
                    i.dwSize,
                    i.pcPriClassBase,
                    i.szExeFile,
                    i.th32DefaultHeapID,
                    i.th32ModuleID,
                    i.th32ParentProcessID,
                    i.th32ProcessID,
                ]
            )
        return toreturn

    def SimpleGetProcesses(self):
        toreturn = []
        for i in self.getRawProcesses():
            toreturn.append({"Name": i[5].decode(), "Threads": i[0], "ProcessId": i[9]})
        return toreturn

    def YieldForProgram(self, programName, AutoOpen: bool = False, Limit=1):
        Count = 0
        while True:
            if Count >= Limit:
                return False
            ProcessesList = self.SimpleGetProcesses()
            for i in ProcessesList:
                if i["Name"] == programName:

                    if AutoOpen:
                        self.Pymem.open_process_from_id(i["ProcessId"])
                        self.ProgramName = programName
                        self.Handle = self.Pymem.process_handle
                        self.is64bit = pymem.process.is_64_bit(self.Handle)
                        self.ProcessID = self.Pymem.process_id
                        self.PID = self.ProcessID
                    return True
            time.sleep(1)
            Count += 1




ChaoSpolit = ChaoSpolit()


print(Colorate.Horizontal(Colors.cyan_to_blue, f"Waiting for {selector}", 1))
while True:
    if ChaoSpolit.YieldForProgram(f"{selector}", True, 15):
        break

                

def ReadRobloxString(ExpectedAddress: int) -> str:
        try:
            StringCount = ChaoSpolit.Pymem.read_int(ExpectedAddress + 0x10)
            if StringCount > 15:
                return ChaoSpolit.Pymem.read_string(ChaoSpolit.DRP(ExpectedAddress), StringCount)
            return ChaoSpolit.Pymem.read_string(ExpectedAddress, StringCount)
        except TypeError as e:
            print(f"TypeError: {e} \n" + "Rsp3")
            exit()

def GetClassName(Instance: int) -> str:
    ExpectedAddress = ChaoSpolit.DRP(ChaoSpolit.DRP(Instance + 0x18) + 8)
    return ReadRobloxString(ExpectedAddress)

def setParent(Instance, Parent, parentOffset, childrenOffset):
    ChaoSpolit.Pymem.process_handle = ctypes.windll.kernel32.OpenProcess(
                    0x1F0FFF,  # PROCESS_ALL_ACCESS
                    False,  # False = do not inherit handles
                    ChaoSpolit.Pymem.process_id,
                )

                # Define necessary ChaoSpolit functions
    PAGE_EXECUTE_READWRITE = 0x40
    ntdll = ctypes.windll.ntdll
    NtProtectVirtualMemory = ntdll.NtProtectVirtualMemory
    NtProtectVirtualMemory.restype = ctypes.c_long

                # Get the base address of the process
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Remove read/write protection from the process memory
    old_protect = ctypes.c_ulong()
    size = ctypes.c_size_t(0x1000)
    NtProtectVirtualMemory(
        ChaoSpolit.Pymem.process_handle,
        ctypes.byref(ctypes.c_void_p(base_address)),
        ctypes.byref(size),
        PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect),
    )

                # Get the base address of the process again (after removing read/write protection)
    base_address = ctypes.windll.kernel32.GetModuleHandleW(None)

                # Re-enable read/write protection for the process memory
    NtProtectVirtualMemory(
                    ChaoSpolit.Pymem.process_handle,
                    ctypes.byref(ctypes.c_void_p(base_address)),
                    ctypes.byref(size),
                    old_protect,
                    ctypes.byref(ctypes.c_ulong()),
    )
    
    ChaoSpolit.Pymem.write_longlong(Instance + parentOffset, Parent)
    newChildren = ChaoSpolit.Pymem.allocate(0x400)
    ChaoSpolit.Pymem.write_longlong(newChildren, newChildren + 0x40)

    ptr = ChaoSpolit.Pymem.read_longlong(Parent + childrenOffset)
    childrenStart, childrenEnd = ChaoSpolit.Pymem.read_longlong(ptr), ChaoSpolit.Pymem.read_longlong(ptr + 8)

    if childrenStart == 0 or childrenEnd == 0 or childrenEnd <= childrenStart or (length := childrenEnd - childrenStart) < 0:
        print("\033[91mError: Invalid children range. Line: Rsp16\033[0m" if childrenStart == 0 or childrenEnd == 0 or childrenEnd <= childrenStart else "\033[91mError: Negative length for children array. Line: Rsp17\033[0m")
        exit()

    b = ChaoSpolit.Pymem.read_bytes(childrenStart, length)
    ChaoSpolit.Pymem.write_bytes(newChildren + 0x40, b, len(b))
    e = newChildren + 0x40 + length
    ChaoSpolit.Pymem.write_longlong(e, Instance)
    ChaoSpolit.Pymem.write_longlong(e + 8, ChaoSpolit.Pymem.read_longlong(Instance + 0x10))
    e += 0x10
    ChaoSpolit.Pymem.write_longlong(newChildren + 0x8, e)
    ChaoSpolit.Pymem.write_longlong(newChildren + 0x10, e)


def inject():
    nameOffset = 72
    parentOffset = 96
    childrenOffset = 80 

    def GetDataModel() -> int:# lua and cipher
        guiroot_pattern = b"\\x47\\x75\\x69\\x52\\x6F\\x6F\\x74\\x00\\x47\\x75\\x69\\x49\\x74\\x65\\x6D"
        guiroot_address = ChaoSpolit.AOBSCANALL(guiroot_pattern, xreturn_multiple=False)
        if guiroot_address != 0:
            RawDataModel = ChaoSpolit.DRP(guiroot_address + 0x38)
            DataModel = RawDataModel + 0x150
            return DataModel - 0x8
        else:
            print("Critical Error please restart the program")
            exit()  
    from concurrent.futures import ThreadPoolExecutor

    def check_ptr(i):
        ptr = ChaoSpolit.Pymem.read_longlong(dataModel + i)
        if ptr:
            try:
                childrenStart = ChaoSpolit.Pymem.read_longlong(ptr)
                childrenEnd = ChaoSpolit.Pymem.read_longlong(ptr + 8)
                if childrenStart and childrenEnd:
                    diff = childrenEnd - childrenStart
                    if diff > 1 and diff < 0x1000:
                        return i
            except:
                pass
        return None

    dataModel = GetDataModel()

    with ThreadPoolExecutor() as executor:
        for result in executor.map(check_ptr, range(0x10, 0x200 + 8, 8)):
            if result is not None:
                childrenOffset = result
                break
    print(Colorate.Horizontal(Colors.cyan_to_blue, "Datamodel Scanning Completed Successfully", 1))

    def GetNameAddress(Instance: int) -> int:
        try:
        
                ExpectedAddress = ChaoSpolit.DRP(Instance + nameOffset, True)


                return ExpectedAddress
        except TypeError as e:
            print(f"TypeError: {e} \n" + "Line: Rsp8")
            exit() 

        

    def GetName(Instance: int) -> str:
        ExpectedAddress = GetNameAddress(Instance)
        return ReadRobloxString(ExpectedAddress)

    def GetChildren(Instance: int) -> str:
        ChildrenInstance = []
        InstanceAddress = Instance
        if not InstanceAddress:
            return False
        ChildrenStart = ChaoSpolit.DRP(InstanceAddress + childrenOffset, True)
        if ChildrenStart == 0:
            return []
        ChildrenEnd = ChaoSpolit.DRP(ChildrenStart + 8, True)
        OffsetAddressPerChild = 0x10
        CurrentChildAddress = ChaoSpolit.DRP(ChildrenStart, True)
        read_longlong = ChaoSpolit.Pymem.read_longlong  # Store in a local variable
        try:
            while CurrentChildAddress != ChildrenEnd:
                ChildrenInstance.append(read_longlong(CurrentChildAddress))
                CurrentChildAddress += OffsetAddressPerChild
            return ChildrenInstance
        except ValueError as e:
            print(f"\033[91mError: {e}\033[0m")
            exit()

    def GetParent(Instance: int) -> int:
        return ChaoSpolit.DRP(Instance + parentOffset, True)

    def FindFirstChild(Instance: int, ChildName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetName(i) == ChildName:
                return i

    def FindFirstChildOfClass(Instance: int, ClassName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetClassName(i) == ClassName:
                return i
            
    def GetDescendants(Instance: int) -> list:

        descendants = []

        def _get_descendants_recursive(current_instance: int):
            children = GetChildren(current_instance)
            descendants.extend(children)  # Add direct children

            # Recurse into each child
            for child in children:
                _get_descendants_recursive(child)

        _get_descendants_recursive(Instance)
        return descendants
    



    class toInstance:
        def __init__(self, address: int = 0):
            self.Address = address
            self.Self = address
            self.Name = GetName(address)
            self.ClassName = GetClassName(address)
            self.Parent = GetParent(address)

        def getChildren(self):
            return GetChildren(self.Address)

        def findFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def findFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def setParent(self, Parent):
            setParent(self.Address, Parent)

        def GetChildren(self):
            return GetChildren(self.Address)

        def GetDescendants(self):
            return GetDescendants(self.Address)

        def FindFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def FindFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def SetParent(self, Parent):
            setParent(self.Address, Parent, parentOffset, childrenOffset)




    print("Injecting...")

    results = ChaoSpolit.AOBSCANALL("496E6A656374????????????????????06", True)
    if results == []:
        print("\033[35mPlease find another teleporter! Line: Rsp11\033[0m")
        return None
    for rn in results:
        result = rn
        bres = ChaoSpolit.d2h(result)
        aobs = "".join(bres[i - 1: i] for i in range(1, 17))
        aobs = ChaoSpolit.hex2le(aobs)
        first = False
        res = ChaoSpolit.AOBSCANALL(aobs, True)
        if res:
            valid = False
            for i in res:
                result = i
                offset_result = result - nameOffset
                try:
                    if ChaoSpolit.Pymem.read_longlong(offset_result + 8) == offset_result:
                        injectScript = offset_result
                        break
                except:
                    pass
        if valid:
            break

    game = toInstance(dataModel)
    players = toInstance(game.FindFirstClass("Players"))
    localPlayer = toInstance(players.GetChildren()[0])

    
    
    localBackpack = toInstance(localPlayer.FindFirstClass("Backpack"))
    tools = localBackpack.GetChildren()
    if len(tools) > 0:
        import hashlib
        tool = toInstance(tools[0])
        targetScript = toInstance(tool.findFirstClass("LocalScript"))
        injectScript = toInstance(injectScript)
        chunk_size = 40


        original_data = b""

        for i in range(0, 0x150, chunk_size):
            chunk = ChaoSpolit.Pymem.read_bytes(injectScript.Self + 0x100 + i, chunk_size)
            original_data += chunk
            time.sleep(random.uniform(0.05, 0.1))
        original_hash = hashlib.md5(ChaoSpolit.Pymem.read_bytes(injectScript.Self + 0x100, 0x150)).hexdigest()
        if original_hash != hashlib.md5(original_data).hexdigest():
            for i in range(0, 0x150, chunk_size):
                chunk = original_data[i:i + chunk_size]
                ChaoSpolit.Pymem.write_bytes(targetScript.Self + 0x100 + i, chunk, len(chunk))
                time.sleep(random.uniform(0.05, 0.1))
            coreGui = toInstance(game.GetChildren()[31])
            targetScript.SetParent(coreGui.Self)                
            print("Successfully attached to this Tool:", tool.Name)
            return True
    else:
        pass
        
    workspace = toInstance(game.GetChildren()[0])
    character_found = False
    
    character_found = False
    for obj in workspace.GetDescendants():
        obj_name = GetName(obj)
        if obj_name == localPlayer.Name:
            character = toInstance(obj)
            print("Found Character")
            character_found = True
            break

    if not character_found:
        print("No Character")
        return None

    injectScript = toInstance(injectScript)
    import hashlib
    animateScript = character.findFirstClass("LocalScript")
    targetScript = toInstance(animateScript)
    chunk_size = 20


    original_data = b""

    for i in range(0, 0x150, chunk_size):
        chunk = ChaoSpolit.Pymem.read_bytes(injectScript.Self + 0x100 + i, chunk_size)
        original_data += chunk
  
    original_hash = hashlib.md5(ChaoSpolit.Pymem.read_bytes(injectScript.Self + 0x100, 0x150)).hexdigest()
    if original_hash != hashlib.md5(original_data).hexdigest():
        for i in range(0, 0x150, chunk_size):
            chunk = original_data[i:i + chunk_size]
            ChaoSpolit.Pymem.write_bytes(targetScript.Self + 0x100 + i, chunk, len(chunk))
            
    coreGui = toInstance(game.GetChildren()[31])
    targetScript.SetParent(coreGui.Self)         
    return True



if __name__ == "__main__":
    global name
    name = threading.Thread(target=undetectname)
    name.start()
    
    input("Press Enter to inject!")
    if inject():
        Roblox = ChaoSpolit.YieldForProgram(f"{selector}")
        print("Reset your character to load the executor")
        stop_thread = True  # Stop the thread
        name.join()  # Wait for the thread to finish
        os._exit(1)
    else:
        Roblox = ChaoSpolit.YieldForProgram(f"{selector}")
        print("\033[35mError during injection! Line: Rsp12\033[0m")