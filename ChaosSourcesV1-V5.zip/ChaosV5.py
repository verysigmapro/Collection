'''
    Chaosploit v4
    @disvanity
'''
import os, pymem, re, time, ctypes, sys, time, random, hashlib

''' Variables & Functions '''
Colors = {
    'RED': '\033[91m',
    'GREEN': '\033[92m',
    'YELLOW': '\033[93m',
    'BLUE': '\033[94m',
    'MAGENTA': '\033[95m',
    'CYAN': '\033[96m',
    'GREY': '\033[90m',
    'RESET': '\033[0m',
    'MAGENTA': '\033[35m'
}
Banner = f"""{Colors['MAGENTA']}
_________ .__                         
\_   ___ \|  |__ _____    ____  ______
/    \  \/|  |  \\__  \  /  _ \/  ___/
\     \___|   Y  \/ __ \(  <_> )___ \ 
 \______  /___|  (____  /\____/____  >
        \/     \/     \/           \/ 
 @{Colors["RESET"]}disvanity & {Colors['MAGENTA']}@{Colors['RESET']}cipher_official{Colors['MAGENTA']}
 ~ {Colors['RESET']}.gg/chaosploit
{Colors['RESET']}"""
def clear():
    if sys.platform == "win32":
        os.system('cls')
    else:
        os.system('clear')

def notify(*txt: str):
    newmsg = ""
    for string in txt:
        newmsg = newmsg + " " + str(string)

    print(f"{Colors['MAGENTA']}Chaos Client {Colors['RESET']}: {newmsg}")

def exit():
    notify("Chaos has been suspended")
    while True:
        pass

''' Request Elevation '''
if sys.platform == 'win32':
    if not ctypes.windll.shell32.IsUserAnAdmin():
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
        sys.exit(0)

''' Chaos Variables '''
chaosInjected = False
PlaceId = 0
FreezeWhileScanning = False
parentOffset = 0x01
childrenOffset = 0x02
parentOffset = 0x03
gotChaos = False
attachedChaos = False

''' Chaos Preference '''
clear()
os.system('title Chaos && mode con: cols=105 lines=35')
print(Banner)
notify("Please ensure you've went through the teleporter")
input("[ENTER] to attach")

''' Init Chaos '''
class Exploit:
    def __init__(self, ProgramName=None):
        self.ProgramName = ProgramName
        self.Pymem = pymem.Pymem()
        self.Addresses = {}
        self.Handle = None
        self.is64bit = False
        self.ProcessID = None
        self.PID = self.ProcessID
        self.First = True
        if type(ProgramName) == str:
            self.Pymem = pymem.Pymem(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = not pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID
        elif type(ProgramName) == int:
            self.Pymem.open_process_from_id(ProgramName)
            self.Handle = self.Pymem.process_handle
            self.is64bit = not pymem.process.is_64_bit(self.Handle)
            self.ProcessID = self.Pymem.process_id
            self.PID = self.ProcessID

    def h2d(self, hz: str, bit: int = 16) -> int:
        if type(hz) == int:
            return hz
        return int(hz, bit)

    def d2h(self, dc: int, UseAuto=None) -> str:
        if type(dc) == str:
            return dc
        if UseAuto:
            if UseAuto == 32:
                dc = hex(dc & (2**32 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2**64 - 1)).replace("0x", "")
        else:
            if abs(dc) > 4294967295:
                dc = hex(dc & (2**64 - 1)).replace("0x", "")
            else:
                dc = hex(dc & (2**32 - 1)).replace("0x", "")
        if len(dc) > 8:
            while len(dc) < 16:
                dc = "0" + dc
        if len(dc) < 8:
            while len(dc) < 8:
                dc = "0" + dc
        return dc

    def PLAT(self, aob: str):
        if type(aob) == bytes:
            return aob
        trueB = bytearray(b"")
        aob = aob.replace(" ", "")
        PLATlist = []
        for i in range(0, len(aob), 2):
            PLATlist.append(aob[i : i + 2])
        for i in PLATlist:
            if "?" in i:
                trueB.extend(b".")
            if "?" not in i:
                trueB.extend(re.escape(bytes.fromhex(i)))
        return bytes(trueB)

    def AOBSCANALL(self, AOB_HexArray, xreturn_multiple=False):
        return pymem.pattern.pattern_scan_all(
            self.Pymem.process_handle,
            self.PLAT(AOB_HexArray),
            return_multiple=xreturn_multiple,
        )

    def gethexc(self, hex: str):
        hex = hex.replace(" ", "")
        hxlist = []
        for i in range(0, len(hex), 2):
            hxlist.append(hex[i : i + 2])
        return len(hxlist)

    def hex2le(self, hex: str):
        lehex = hex.replace(" ", "")
        lelist = []
        if len(lehex) > 8:
            while len(lehex) < 16:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i : i + 2])
            lelist.reverse()
            return "".join(lelist)
        if len(lehex) < 9:
            while len(lehex) < 8:
                lehex = "0" + lehex
            for i in range(0, len(lehex), 2):
                lelist.append(lehex[i : i + 2])
            lelist.reverse()
            return "".join(lelist)

    def calcjmpop(self, des, cur):
        jmpopc = (self.h2d(des) - self.h2d(cur)) - 5
        jmpopc = hex(jmpopc & (2**32 - 1)).replace("0x", "")
        if len(jmpopc) % 2 != 0:
            jmpopc = "0" + str(jmpopc)
        return jmpopc

    def isProgramGameActive(self):
        try:
            self.Pymem.read_char(self.Pymem.base_address)
            return True
        except:
            return False

    def DRP(self, Address: int, is64Bit: bool = None) -> int:
        Address = Address
        if type(Address) == str:
            Address = self.h2d(Address)
        if is64Bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        if self.is64bit:
            return int.from_bytes(self.Pymem.read_bytes(Address, 8), "little")
        return int.from_bytes(self.Pymem.read_bytes(Address, 4), "little")

    def isValidPointer(self, Address: int, is64Bit: bool = None) -> bool:
        try:
            if type(Address) == str:
                Address = self.h2d(Address)
            self.Pymem.read_bytes(self.DRP(Address, is64Bit), 1)
            return True
        except:
            return False

    def GetModules(self) -> list:
        return list(self.Pymem.list_modules())

    def getAddressFromName(self, Address: str) -> int:
        if type(Address) == int:
            return Address
        AddressBase = 0
        AddressOffset = 0
        for i in self.GetModules():
            if i.name in Address:
                AddressBase = i.lpBaseOfDll
                AddressOffset = self.h2d(Address.replace(i.name + "+", ""))
                AddressNamed = AddressBase + AddressOffset
                return AddressNamed
        notify("Unable to find Address:",Address)
        return Address

    def getNameFromAddress(self, Address: int) -> str:
        memoryInfo = pymem.memory.virtual_query(self.Pymem.process_handle, Address)
        BaseAddress = memoryInfo.BaseAddress
        NameOfDLL = ""
        AddressOffset = 0
        for i in self.GetModules():
            if i.lpBaseOfDll == BaseAddress:
                NameOfDLL = i.name
                AddressOffset = Address - BaseAddress
                break
        if NameOfDLL == "":
            return Address
        NameOfAddress = NameOfDLL + "+" + self.d2h(AddressOffset)
        return NameOfAddress

    def getRawProcesses(self):
        toreturn = []
        for i in pymem.process.list_processes():
            toreturn.append(
                [
                    i.cntThreads,
                    i.cntUsage,
                    i.dwFlags,
                    i.dwSize,
                    i.pcPriClassBase,
                    i.szExeFile,
                    i.th32DefaultHeapID,
                    i.th32ModuleID,
                    i.th32ParentProcessID,
                    i.th32ProcessID,
                ]
            )
        return toreturn

    def SimpleGetProcesses(self):
        toreturn = []
        for i in self.getRawProcesses():
            toreturn.append({"Name": i[5].decode(), "Threads": i[0], "ProcessId": i[9]})
        return toreturn

    def YieldForProgram(self, programName, AutoOpen: bool = False):
        Count = 0
        while True:
            ProcessesList = self.SimpleGetProcesses()
            for i in ProcessesList:
                if i["Name"] == programName:
                    notify(
                        "Found "
                        + programName
                        + " with Process ID: "
                        + str(i["ProcessId"])
                    )
                    if AutoOpen:
                        self.Pymem.open_process_from_id(i["ProcessId"])
                        self.ProgramName = programName
                        self.Handle = self.Pymem.process_handle
                        self.is64bit = not pymem.process.is_64_bit(self.Handle)
                        self.ProcessID = self.Pymem.process_id
                        self.PID = self.ProcessID
                        notify("Successfully found "+ str(programName))
                    return True
            if self.First:
                notify("Waiting for the Program '" + programName + "'")
            self.First = False
            time.sleep(1)
            Count += 1

    def ReadPointer(
        self, BaseAddress: int, Offsets_L2R: list, is64Bit: bool = None
    ) -> int:
        x = self.DRP(BaseAddress, is64Bit)
        y = Offsets_L2R
        z = x
        if y == None or len(y) == 0:
            return z
        count = 0
        for i in y:
            try:
                # notify(self.d2h(x + i))
                # notify(self.d2h(i))
                z = self.DRP(z + i, is64Bit)
                count += 1
                # notify(self.d2h(z))
            except:
                notify("Failed to read Offset at Index: " + str(count))
                return z
        return z

    def GetMemoryInfo(self, Address: int, Handle: int = None):
        if Handle:
            return pymem.memory.virtual_query(Handle, Address)
        else:
            return pymem.memory.virtual_query(self.Handle, Address)

    def MemoryInfoToDictionary(self, MemoryInfo):
        return {
            "BaseAddress": MemoryInfo.BaseAddress,
            "AllocationBase": MemoryInfo.AllocationBase,
            "AllocationProtect": MemoryInfo.AllocationProtect,
            "RegionSize": MemoryInfo.RegionSize,
            "State": MemoryInfo.State,
            "Protect": MemoryInfo.Protect,
            "Type": MemoryInfo.Type,
        }

    def SetProtection(
        self,
        Address: int,
        ProtectionType=0x40,
        Size: int = 4,
        OldProtect=ctypes.c_ulong(0),
    ):
        pymem.ressources.kernel32.VirtualProtectEx(
            self.Pymem.process_handle,
            Address,
            Size,
            ProtectionType,
            ctypes.byref(OldProtect),
        )
        return OldProtect

    def ChangeProtection(
        self,
        Address: int,
        ProtectionType=0x40,
        Size: int = 4,
        OldProtect=ctypes.c_ulong(0),
    ):
        return self.SetProtection(Address, ProtectionType, Size, OldProtect)

    def GetProtection(self, Address: int):
        return self.GetMemoryInfo(Address).Protect

    def KnowProtection(self, Protection):
        if Protection == 0x10:
            return "PAGE_EXECUTE"
        if Protection == 0x20:
            return "PAGE_EXECUTE_READ"
        if Protection == 0x40:
            return "PAGE_EXECUTE_READWRITE"
        if Protection == 0x80:
            return "PAGE_EXECUTE_WRITECOPY"
        if Protection == 0x01:
            return "PAGE_NOACCESS"
        if Protection == 0x02:
            return "PAGE_READONLY"
        if Protection == 0x04:
            return "PAGE_READWRITE"
        if Protection == 0x08:
            return "PAGE_WRITECOPY"
        if Protection == 0x100:
            return "PAGE_GUARD"
        if Protection == 0x200:
            return "PAGE_NOCACHE"
        if Protection == 0x400:
            return "PAGE_WRITECOMBINE"
        if Protection in ["PAGE_EXECUTE", "execute", "e"]:
            return 0x10
        if Protection in [
            "PAGE_EXECUTE_READ",
            "execute read",
            "read execute",
            "execute_read",
            "read_execute",
            "er",
            "re",
        ]:
            return 0x20
        if Protection in [
            "PAGE_EXECUTE_READWRITE",
            "execute read write",
            "execute write read",
            "write execute read",
            "write read execute",
            "read write execute",
            "read execute write",
            "erw",
            "ewr",
            "wre",
            "wer",
            "rew",
            "rwe",
        ]:
            return 0x40
        if Protection in [
            "PAGE_EXECUTE_WRITECOPY",
            "execute copy write",
            "execute write copy",
            "write execute copy",
            "write copy execute",
            "copy write execute",
            "copy execute write",
            "ecw",
            "ewc",
            "wce",
            "wec",
            "cew",
            "cwe",
        ]:
            return 0x80
        if Protection in ["PAGE_NOACCESS", "noaccess", "na", "n"]:
            return 0x01
        if Protection in ["PAGE_READONLY", "readonly", "ro", "r"]:
            return 0x02
        if Protection in ["PAGE_READWRITE", "read write", "write read", "wr", "rw"]:
            return 0x04
        if Protection in ["PAGE_WRITECOPY", "write copy", "copy write", "wc", "cw"]:
            return 0x08
        if Protection in ["PAGE_GUARD", "pg", "guard", "g"]:
            return 0x100
        if Protection in ["PAGE_NOCACHE", "nc", "nocache"]:
            return 0x200
        if Protection in ["PAGE_WRITECOMBINE", "write combine", "combine write"]:
            return 0x400
        return Protection

    def Suspend(self, pid: int = None):
        kernel32 = ctypes.WinDLL("kernel32.dll")
        if pid:
            kernel32.DebugActiveProcess(pid)
        if self.PID:
            kernel32.DebugActiveProcess(self.PID)

    def Resume(self, pid: int = None):
        kernel32 = ctypes.WinDLL("kernel32.dll")
        if pid:
            kernel32.DebugActiveProcessStop(pid)
        if self.PID:
            kernel32.DebugActiveProcessStop(self.PID)
Chaos = Exploit()

while True:
    if Chaos.YieldForProgram("RobloxPlayerBeta.exe", True):
        break

def ReadRobloxString(ExpectedAddress: int) -> str:
    StringCount = Chaos.Pymem.read_int(ExpectedAddress + 0x10)
    if StringCount > 15:
        return Chaos.Pymem.read_string(Chaos.DRP(ExpectedAddress), StringCount)
    return Chaos.Pymem.read_string(ExpectedAddress, StringCount)

def GetClassName(Instance: int) -> str:
    ExpectedAddress = Chaos.DRP(Chaos.DRP(Instance + 0x18) + 8)
    return ReadRobloxString(ExpectedAddress)

def SetParent(Instance, Parent):
    Chaos.Pymem.write_longlong(Instance + parentOffset, Parent)
    newChildren = Chaos.Pymem.allocate(0x400)
    Chaos.Pymem.write_longlong(newChildren + 0, newChildren + 0x40)
    ptr = Chaos.Pymem.read_longlong(Parent + childrenOffset)
    childrenStart = Chaos.Pymem.read_longlong(ptr)
    childrenEnd = Chaos.Pymem.read_longlong(ptr + 8)
    b = Chaos.Pymem.read_bytes(childrenStart, childrenStart - childrenEnd)
    Chaos.Pymem.write_bytes(newChildren + 0x40, b, len(b))
    e = newChildren + 0x40 + (childrenEnd - childrenStart)
    Chaos.Pymem.write_longlong(e, Instance)
    Chaos.Pymem.write_longlong(e + 8, Chaos.Pymem.read_longlong(Instance + 0x10))
    e = e + 0x10
    Chaos.Pymem.write_longlong(newChildren + 0x8, e)
    Chaos.Pymem.write_longlong(newChildren + 0x10, e)
    notify("Set parent " + str(Instance) + " to " + str(Parent))

def attachChaos():
    global gotChaos
    global attachedChaos
    notify("")
    notify("Attempting to attach Chaos")
    for file in os.listdir(f"C:/Users/{os.getlogin()}/AppData/Local/Roblox/logs"):
        try:
            os.remove(f"C:/Users/{os.getlogin()}/AppData/Local/Roblox/logs/"+file)
        except:
            pass

    # STAGE 1
    try:
        notify("Beginning stage 1")
        nameOffset = 72
        parentOffset = 96
        childrenOffset = 80 
        guiroot_pattern = b"\\x47\\x75\\x69\\x52\\x6F\\x6F\\x74\\x00\\x47\\x75\\x69\\x49\\x74\\x65\\x6D"
        guiroot_address = Chaos.AOBSCANALL(guiroot_pattern, xreturn_multiple=False)
        if guiroot_address and guiroot_address != 0:
            RawDataModel = Chaos.DRP(guiroot_address + 0x38)
            DataModel = RawDataModel + 0x198
        else:
            notify("Invalid model.\nERR0X6")
            exit()
        dataModel = DataModel - 0x8
    except Exception as e:
        notify("Unexpected issue in stage 1\n",e)
        exit()

    def GetNameAddress(Instance: int) -> int:
        ExpectedAddress = Chaos.DRP(Instance + nameOffset, True)
        return ExpectedAddress

    def GetName(Instance: int) -> str:
        ExpectedAddress = GetNameAddress(Instance)
        return ReadRobloxString(ExpectedAddress)

    def GetChildren(Instance: int) -> str:
        ChildrenInstance = []
        InstanceAddress = Instance
        if not InstanceAddress:
            return False
        ChildrenStart = Chaos.DRP(InstanceAddress + childrenOffset, True)
        if ChildrenStart == 0:
            return []
        ChildrenEnd = Chaos.DRP(ChildrenStart + 8, True)
        OffsetAddressPerChild = 0x10
        CurrentChildAddress = Chaos.DRP(ChildrenStart, True)
        for i in range(0, 9000):
            if i == 8999:
                notify("Too many children, may cause issues.")
            if CurrentChildAddress == ChildrenEnd:
                break
            ChildrenInstance.append(Chaos.Pymem.read_longlong(CurrentChildAddress))
            CurrentChildAddress += OffsetAddressPerChild
        return ChildrenInstance

    def GetParent(Instance: int) -> int:
        return Chaos.DRP(Instance + parentOffset, True)

    def FindFirstChild(Instance: int, ChildName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetName(i) == ChildName:
                return i

    def FindFirstChildOfClass(Instance: int, ClassName: str) -> int:
        ChildrenOfInstance = GetChildren(Instance)
        for i in ChildrenOfInstance:
            if GetClassName(i) == ClassName:
                return i

    def GetDescendants(Instance: int) -> list:

        descendants = []

        def _get_descendants_recursive(current_instance: int):
            children = GetChildren(current_instance)
            descendants.extend(children)  # Add direct children

            # Recurse into each child
            for child in children:
                _get_descendants_recursive(child)

        _get_descendants_recursive(Instance)
        return descendants

    class toInstance:
        def __init__(self, address: int = 0):
            self.Address = address
            self.Self = address
            self.Name = GetName(address)
            self.ClassName = GetClassName(address)
            self.Parent = GetParent(address)

        def getChildren(self):
            return GetChildren(self.Address)

        def findFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def findFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def setParent(self, Parent):
            SetParent(self.Address, Parent)

        def GetDescendants(self):
            return GetDescendants(self.Address)

        def GetChildren(self):
            return GetChildren(self.Address)

        def FindFirstChild(self, ChildName):
            return FindFirstChild(self.Address, ChildName)

        def FindFirstClass(self, ChildClass):
            return FindFirstChildOfClass(self.Address, ChildClass)

        def SetParent(self, Parent):
            SetParent(self.Address, Parent)

    # STAGE 2
    try:
        notify("Beginning stage 2")
        game = toInstance(dataModel)
        players = toInstance(game.FindFirstClass("Players"))
        localPlayer = toInstance(players.GetChildren()[0])
        workspace = toInstance(game.GetChildren()[0])
        character_found = False

        for obj in workspace.GetDescendants():
            obj_name = GetName(obj)
            if obj_name == localPlayer.Name:
                character = toInstance(obj)
                character_found = True
                break

        if not character_found:
            notify("Invalid asset.\nERR0X3")
            return None

        animateScript = character.findFirstClass("LocalScript")
        if animateScript == None:
            notify("Invalid asset.\nERR0X4")
            return None
        notify("Fetched required assets")
    except Exception as e:
        notify("Unexpected issue in stage 2\n",e)
        exit()

    # STAGE 3
    try:
        valid = False
        notify("Beginning stage 3")
        targetScript = toInstance(animateScript)
        injectScript = None
        results = Chaos.AOBSCANALL("496E6A656374????????????????????06", True)
        if results == []:
            notify("Invalid library results.\nERR0X5")
            return None
        # print('results', results)
        for rn in results:
            time.sleep(5)
            result = rn
            bres = Chaos.d2h(result)
            aobs = "".join(bres[i - 1: i] for i in range(1, 17))
            aobs = Chaos.hex2le(aobs)
            res = Chaos.AOBSCANALL(aobs, True)
            if res:
                # print("response", res)
                valid = False
                for i in res:
                    result = i
                    offset_result = result - nameOffset
                    # print("offset", offset_result)
                    try:
                        if Chaos.Pymem.read_longlong(offset_result + 8) == offset_result:
                            injectScript = offset_result
                            # print('inject', injectScript)
                            break
                    except:
                        pass
            if valid:
                break
        notify("Fetched required libraries")
        injectScript = toInstance(injectScript)
        notify("Fetched required asset")
        time.sleep(5)
        Bytecode = Chaos.Pymem.read_bytes(injectScript.Self + 0x100, 0x150)
        notify("Read bytecode")
        time.sleep(5)
        Chaos.Pymem.write_bytes(targetScript.Self + 0x100, Bytecode, len(Bytecode))
        notify("Chaos successfully attached")
    except Exception as e:
        notify("Unexpected issue in stage 3\n",e)
        exit()
    attachedChaos = True
    return True

while attachedChaos == False:
    try:
        attachChaos()
    except TypeError as e:
        notify("Potential issue with game or libraries")
        exit()
    except Exception as e:
        if "Array length must be" in str(e):
            notify(f"Invalid attachment place", False)
        elif "5" in str(e):
            notify(f"Access denied to process", False)
            time.sleep(5)
            sys.exit()
        elif "299" in str(e):
            notify(f"ProcessMemory incompletion, re-attempting", False)        
        else:
            notify(f"Error occured in attachment process, re-attempting\n     {Colors['RED']}{e}{Colors['RESET']}", False)

while attachedChaos == True:
    pass